#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QColorDialog>
#include <QLabel>
#include <QMouseEvent> // to detect all the mouse events
#include <iostream>
using namespace std;

#define height 600 // set the height of the drawing area
#define width 1000  // set the width of the drawing area

QImage img(width, height, QImage::Format_RGB888);       // this is the drawing area
QRgb rgb(qRgb(255, 255, 255));                          // color bit which is set to white by default

MainWindow::MainWindow(QWidget *parent) // Constructor
    : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    for (int x = 0; x < width; ++x)                     // this is for initial black screen
    {
        for (int y = 0; y < height; ++y)
        {
            img.setPixel(x, y, qRgb(0, 0, 0));
        }
    }
    ui->label->setPixmap(QPixmap::fromImage(img));
    ui->pushButton_5->setEnabled(false);                //clip disabled
    ui->pushButton_4->setEnabled(false);                // clear disabled
}

MainWindow::~MainWindow() // destructor
{
    delete ui;
}

bool mouseEnabled = false;
bool mouseLine = false;

int x1y1[40][2];                    // stores x1-y1 coord for all lines
int LineNo = 0;                     // no of lines present

int diagonal_x[2];                  // diagonal x clipping window
int diagonal_y[2];                  // diagonal y clipping window

int x_min;                         // left of window
int x_max;                          // right of window
int y_min;                         // top of window
int y_max;                        // bottom of window


//DDA line drawing algorithm
void MainWindow::DDALine(float x1, float y1, float x2, float y2)
{
    float dx, dy, step, x, y;
    dx = x2 - x1;
    dy = y2 - y1;
    if (abs(dx) >= abs(dy))
    {
        step = abs(dx);
    }
    else
    {
        step = abs(dy);
    }
    dx = dx / step;
    dy = dy / step;
    int i = 0;
    x = x1;
    y = y1;
    while (i < step)
    {
        x = x + dx;
        y = y + dy;
        img.setPixel(x, y, rgb);
        i++;
    }

    ui->label->setPixmap(QPixmap::fromImage(img));
}
int MainWindow::findRegionCode(double x, double y) // this is code for finding the region code
{
    //4 bit region code system in the algorithm

    /*
                        left	    central	     right

    top             | 1001 =9  |    1000 =1	  | 1010 =5
                    ------------------------------------
    central         | 0001 =8  |    0000 =0	  | 0010 =4
                    ------------------------------------
    bottom          | 0101 =10 |	0100 =2	  | 0110 =6
     */


    //making sure the diagonals are set in ascending order
    if (diagonal_x[0] > diagonal_x[1])
    {
        x_min = diagonal_x[0];
        x_max = diagonal_x[1];
    }
    else
    {
        x_min = diagonal_x[1];
        x_max = diagonal_x[0];
    }

    //making sure the diagonals are in ascending order
    if (diagonal_y[0] > diagonal_y[1])
    {
        y_min = diagonal_y[0];
        y_max = diagonal_y[1];
    }
    else
    {
        y_min = diagonal_y[1];
        y_max = diagonal_y[0];
    }

    //declaring variable for region code
    int regionCode = 0;

    //assigning region code to
    if (x < x_max)
    {
        regionCode |= 8;
    }
    else if (x > x_min)
    {
        regionCode |= 4;
    }
    if (y < y_max)
    {
        regionCode |= 2;
    }
    else if (y > y_min)
    {
        regionCode |= 1;
    }

    return regionCode;
}

void MainWindow::Clip(int x1, int y1, int x2, int y2)
{
    if (diagonal_x[0] > diagonal_x[1])
    {
        x_min = diagonal_x[0];
        x_max = diagonal_x[1];
    }
    else
    {
        x_min = diagonal_x[1];
        x_max = diagonal_x[0];
    }
    if (diagonal_y[0] > diagonal_y[1])
    {
        y_min = diagonal_y[0];
        y_max = diagonal_y[1];
    }
    else
    {
        y_min = diagonal_y[1];
        y_max = diagonal_y[0];
    }

    int code1 = findRegionCode(x1, y1); // find region code of 1st end point
    int code2 = findRegionCode(x2, y2); // find region code of 2nd end point

    bool isVisible = false;

    while (1)
    {
        if (code1 == 0 && code2 == 0) // line completely inside the window
        {
            isVisible = true;
            break;
        }
        else if (code1 & code2) // both are outside so ignore the line
        {
            break;
        }
        else
        {
            isVisible = true;
            int code_out;
            int x=0, y=0;
            if (code1 != 0) // check which point is inside
                code_out = code1;
            else
                code_out = code2;

            if (code_out & 1)
            {
                x = x1 + (x2 - x1) * (y_min - y1) / (y2 - y1);
                y = y_min;
            }
            else if (code_out & 2)
            {
                x = x1 + (x2 - x1) * (y_max - y1) / (y2 - y1);
                y = y_max;
            }
            else if (code_out & 4)
            {
                y = y1 + (y2 - y1) * (x_min - x1) / (x2 - x1);
                x = x_min;
            }
            else if (code_out & 8)
            {
                y = y1 + (y2 - y1) * (x_max - x1) / (x2 - x1);
                x = x_max;
            }

            if (code_out == code1)
            {
                x1 = x;
                y1 = y;
                code1 = findRegionCode(x1, y1);
            }
            else
            {
                x2 = x;
                y2 = y;
                code2 = findRegionCode(x2, y2);
            }
        }
    }

    if (isVisible)
        DDALine(x1, y1, x2, y2);
}

int k1 = 0;


void MainWindow::mousePressEvent(QMouseEvent *event)
{
    if (mouseLine)
    {
        if (mouseEnabled == true)
        {
            int p = event->pos().x()-10;
            int q = event->pos().y()-30;
            x1y1[LineNo][0] = p;
            x1y1[LineNo][1] = q;

            if (event->button() == Qt::RightButton)     //change
            {
                if(LineNo%2==1)
                {
                    DDALine(x1y1[LineNo][0], x1y1[LineNo][1], x1y1[LineNo - 1][0], x1y1[LineNo - 1][1]);
                    mouseEnabled = false;
                    QMessageBox messageBox;
                    messageBox.information(0, "Message", "Line Complete");

                    ui->pushButton_2->setEnabled(false);
                    if (k1 != 0)
                    {
                        ui->pushButton_5->setEnabled(true);
                    }
                }
                else
                {
                    QMessageBox messageBox;
                    messageBox.information(0, "Message", "Line incomplete.\nNeed one more point before exit!");
                }
            }
            else
            {
                if (LineNo%2==1)
                {
                    DDALine(x1y1[LineNo][0], x1y1[LineNo][1], x1y1[LineNo - 1][0], x1y1[LineNo - 1][1]);
                }
            }
            LineNo++;
            if (LineNo>1)
            {
                ui->pushButton_4->setEnabled(true);
            }
        }
        else
        {
            if (event->button() == Qt::RightButton || event->button() == Qt::LeftButton)
            {
                QMessageBox messageBox;
                messageBox.information(0, "Message", "Mouse Functionality is disabled");
                messageBox.setFixedSize(200, 200);
                return;
            }
        }
    }


    else
    {
        if (mouseEnabled == true)
        {
            int p = event->pos().x();
            int q = event->pos().y();
            diagonal_x[k1] = p;
            diagonal_y[k1] = q;
            k1++;
            if (k1==2)
            {
                DDALine(diagonal_x[0], diagonal_y[0], diagonal_x[1], diagonal_y[0]);
                DDALine(diagonal_x[0], diagonal_y[0], diagonal_x[0], diagonal_y[1]);
                DDALine(diagonal_x[1], diagonal_y[1], diagonal_x[1], diagonal_y[0]);
                DDALine(diagonal_x[1], diagonal_y[1], diagonal_x[0], diagonal_y[1]);
                mouseEnabled = false;
                QMessageBox messageBox;
                messageBox.information(0, "Message", "Window has been completed");
                messageBox.setFixedSize(200, 200);
                if (LineNo > 1)
                {
                    ui->pushButton_5->setEnabled(true);
                }
                ui->pushButton_3->setEnabled(false);
                mouseEnabled = false;
            }
        }
        else
        {
            if (event->button() == Qt::RightButton || event->button() == Qt::LeftButton)
            {
                QMessageBox messageBox;
                messageBox.information(0, "Message", "Mouse button disabled"),
                    messageBox.setFixedSize(200, 200);
                return;
            }
        }
    }
}

//choosing a color with which the lines will be drawn
void MainWindow::on_pushButton_clicked()
{
    QRgb getColor(QColorDialog::getColor().rgb());
    rgb = getColor;
}

//clear screen button
void MainWindow::on_pushButton_4_clicked()
{
    LineNo = 0;
    for (int i = 0; i < 40; i++)
    {
        x1y1[i][0] = -1;
        x1y1[i][1] = -1;
    }
    k1 = 0;
    diagonal_x[0] = 0;
    diagonal_x[1] = 0;
    diagonal_y[0] = 0;
    diagonal_y[1] = 0;

    mouseEnabled = false;
    mouseLine = true;
    for (int x = 0; x < width; ++x) // this is for initial black screen
    {
        for (int y = 0; y < height; ++y)
        {
            img.setPixel(x, y, qRgb(0, 0, 0));
        }
    }
    ui->label->setPixmap(QPixmap::fromImage(img));
    ui->pushButton_2->setEnabled(true);
    ui->pushButton_3->setEnabled(true);
    ui->pushButton_5->setEnabled(false);
    ui->pushButton_4->setEnabled(false);
}

//clipping the lines within the window
void MainWindow::on_pushButton_5_clicked()
{
    for (int x = 0; x < width; ++x) // this is for initial black screen
    {
        for (int y = 0; y < height; ++y)
        {
            img.setPixel(x, y, qRgb(0, 0, 0));
        }
    }
    int i = 0;
    DDALine(diagonal_x[0], diagonal_y[0], diagonal_x[1], diagonal_y[0]);
    DDALine(diagonal_x[0], diagonal_y[0], diagonal_x[0], diagonal_y[1]);
    DDALine(diagonal_x[1], diagonal_y[1], diagonal_x[1], diagonal_y[0]);
    DDALine(diagonal_x[1], diagonal_y[1], diagonal_x[0], diagonal_y[1]);
    for (i = 0; i < LineNo - 1; i=i+2)
    {
        Clip(x1y1[i][0], x1y1[i][1], x1y1[i + 1][0], x1y1[i + 1][1]);

    }

}


//initiating the process for drawing the clipping window
void MainWindow::on_pushButton_3_clicked()
{
    mouseEnabled = true;                //enabling mouse functionality
    mouseLine = false;                  //initiating window drawing sequence
    QMessageBox messageBox;
    messageBox.information(0, "Message", "Mouse functionality enabled");
    messageBox.setFixedSize(200, 200);
    ui->label->setPixmap(QPixmap::fromImage(img));
}

//draw lines button sets the array initially and allows the user to draw the lines
void MainWindow::on_pushButton_2_clicked()
{
    for (int i = 0; i < 40; i++)
    {
        x1y1[i][0] = -1;               //setting all elements of the array to -1
        x1y1[i][1] = -1;
    }
    mouseEnabled = true;                //enabling use of mouse
    mouseLine = true;                   //initiating line drawing sequence
    QMessageBox messageBox;
    messageBox.information(0, "Message", "Mouse functionality enabled"),
    messageBox.setFixedSize(200, 200);
    ui->label->setPixmap(QPixmap::fromImage(img));
}

