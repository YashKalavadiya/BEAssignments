#7 a for odd roll no
#7 b for even
