#8 a for even roll no
#8 b for odd
