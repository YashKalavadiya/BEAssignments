For Matrix 1:
Enter No of rows: 2
Enter number of cols: 3
Enter  2  *  3  matrix(seperate elements of row by single space and new line for col):
1 2 3
4 5 6
[[1, 2, 3], [4, 5, 6]]
For Matrix 2:
Enter no of rows: 2
Enter number of cols: 3
Enter  2  *  3  matrix(seperate elements of row by single space and new line for col):
1 2 3
4 5 6
[[1, 2, 3], [4, 5, 6]]
MENU:
1. Add Two Matrix
2. substract two matrix
3. Multiply two matrix
4. Transpose of matrix
5. Exit
6. Re Enter Matrix
Enter Choice: 1
Addition
 2 4 6
 8 10 12