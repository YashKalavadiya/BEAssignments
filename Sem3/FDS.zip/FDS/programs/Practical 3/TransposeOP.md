For Matrix 1:
Enter No of rows: 1
Enter number of cols: 3
Enter  1  *  3  matrix(seperate elements of row by single space and new line for col):
1 2 3
[[1, 2, 3]]
For Matrix 2:
Enter no of rows: 2
Enter number of cols: 3
Enter  2  *  3  matrix(seperate elements of row by single space and new line for col):
1 2 3
4 5 6
[[1, 2, 3], [4, 5, 6]]
MENU:
1. Add Two Matrix
2. substract two matrix
3. Multiply two matrix
4. Transpose of matrix
5. Exit
6. Re Enter Matrix
Enter Choice: 4
Transpose of maatrix 1: ---------
 1
 2
 3
Transpose of maatrix 2: ---------
 1 4
 2 5
 3 6