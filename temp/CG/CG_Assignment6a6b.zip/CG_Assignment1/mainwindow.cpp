#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QColorDialog>
#include <math.h>
#include <QTime>
#define height 600
#define width 800

QImage img(width, height, QImage::Format_RGB888);
QRgb rgb(qRgb(255,255,255));

MainWindow::MainWindow(QWidget *parent):QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //We will set all the screen pixels to black (0,0,0) so that the window is visible
    for (int x = 0; x < width; ++x)
        {
            for (int y = 0; y < height; ++y)
            {
                img.setPixel(x, y, qRgb(0, 0, 0));      //setting all the pixels on the screen to black (0,0,0)
            }
        }
    ui->label->setPixmap(QPixmap::fromImage(img));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void delay( int millisecondsToWait )
{
    QTime dieTime = QTime::currentTime().addMSecs( millisecondsToWait );
    while( QTime::currentTime() < dieTime )
    {
        QCoreApplication::processEvents( QEventLoop::AllEvents, 100 );
    }
}

void MainWindow::BresenhamCircle(int xCenter, int yCenter, int radius) //defining Bresenham Circle drawing algorithm
{
    int x = 0;
    int y = radius;
    int arr[radius][2], len=0;

    int d = 3 - (2 * radius);       //calculating the initial decision parameter
    while (x <= y)
    {
        if (d > 0)                  //checking the condition for deciding the next parameter
        {
            d = d + 4 * (x - y) + 10;
            y--;
        }
        else
        {
            d = d + (4 * x) + 6;
        }
        x++;
        //Using reflection method to plot the points. Plotting the first octet only

        img.setPixel(xCenter + x, yCenter + y, rgb);        //plotting point P1 (x,y)
        ui->label->setPixmap(QPixmap::fromImage(img));          //plotting the points on the screen
        ui->label->show();
        delay(100);
        //storing the coordinates in an array
        arr[len][0]=x;
        arr[len][1]=y;
        len++;

    }

    //reflecting the entire first octet along
    for(int q=0;q<=len;q++)
    {
        img.setPixel(xCenter + arr[q][0], yCenter - arr[q][1], rgb);        //plotting reflection about X-axis
        img.setPixel(xCenter - arr[q][0], yCenter - arr[q][1], rgb);        //plotting reflection about line X=Y
        img.setPixel(xCenter - arr[q][0], yCenter + arr[q][1], rgb);        //plotting reflection about Y-axis
        img.setPixel(xCenter + arr[q][1], yCenter + arr[q][0], rgb);        //interchanging x and y values and plotting P2
        img.setPixel(xCenter + arr[q][1], yCenter - arr[q][0], rgb);        //plotting reflection about X-axis
        img.setPixel(xCenter - arr[q][1], yCenter - arr[q][0], rgb);        //plotting reflection about line X=Y
        img.setPixel(xCenter - arr[q][1], yCenter + arr[q][0], rgb);        //plotting reflection about Y-axis
        ui->label->setPixmap(QPixmap::fromImage(img));          //plotting the points on the screen
        ui->label->show();
        delay(100);
    }
    ui->label->setPixmap(QPixmap::fromImage(img));          //plotting the points on the screen
    ui->label->show();
}

void MainWindow::BresenhamLine(int x1, int y1, int x2, int y2)
{
    int dx = abs(x2 - x1);                                  //calculating the dx vaue
    int sx;
    //if x1 > x2 then we need to decrement otherwise we increment
    if(x1<x2)
    {
        sx=1;
    }
    else
    {
        sx=-1;
    }

    int dy = -abs(y2 - y1);
    int sy;

    //if y1<y2 then we increment else we decrement
    if(y1<y2)
    {
        sy=1;       //setting up for increment
    }
    else
    {
        sy=-1;      //setting up for decrement
    }
    int err = dx + dy;      // error value as we have taken dy negative so its dx - dy
                            // err is to get the integer value of the nearest pixel

    while (true)
    {
        img.setPixel(x1, y1, rgb);
        if (x1 == x2 && y1 == y2)
            break;
        int e2 = 2 * err;               // calculating the decision parameter
        if (e2 >= dy)                   //checking condition for corresponding increment
        {
            err += dy;                  //getting the integer value of consecutive pixel
            x1 += sx;
        }
        if (e2 <= dx)
        {
            err += dx;
            y1 += sy;
        }
    }
    ui->label->setPixmap(QPixmap::fromImage(img));
}

//defining function for DDA line algorithm
void MainWindow::DDALine(float x1, float y1, float x2, float y2)
{

    float dx = (x2 - x1);       //calculating value of dx
    float dy = (y2 - y1);       //calculating value of dy
    float step;

    //determining the no. of steps for code to run
    if (abs(dx)>=abs(dy))
    {
        step = abs(dx);
    }
    else
    {
        step = abs(dy);
    }

    //value by which coordinates will be incremented every iteration
    dx = dx / step;
    dy = dy / step;

    float x = x1, y = y1;
    int i = 1;                  //setting up increment for calculating no. of steps

    //repeating process for no of steps
    while (i <= step)
    {
        img.setPixel(x, y, rgb);
        x += dx;
        y += dy;
        i++;
    }

    ui->label->setPixmap(QPixmap::fromImage(img));
}

//printing pattern of assignment 6A
void MainWindow::Assignment6a()
{
    int xC = ui->textEdit->toPlainText().toInt();       //getting input from textbox1
    int yC = ui->textEdit_2->toPlainText().toInt();     //getting input from textbox2
    int rad = ui->textEdit_3->toPlainText().toInt();    //getting input from textbox3

    //triangle formed is equilateral
    float x1 = xC + rad * (float)sqrt(3) / 2;
    float x2 = xC - rad * (float)sqrt(3) / 2;
    float y1 = yC + rad / 2;

    //drawing the lines
    DDALine(x1, y1, x2, y1);
    DDALine(x1, y1, xC, (float)yC - rad);
    BresenhamLine(x2, y1, (float)xC, (float)yC - rad);

    //drawing the two concentric circles
    BresenhamCircle(xC, yC, rad);
    BresenhamCircle(xC, yC, rad / 2);
}

//printing pattern of assignment 6B
void MainWindow::Assignment6b()
{
    int x1 = ui->textEdit->toPlainText().toInt();
    int y1 = ui->textEdit_2->toPlainText().toInt();         //getting inputs from respective textboxes

    int x2 = ui->textEdit_4->toPlainText().toInt();
    int y2 = ui->textEdit_5->toPlainText().toInt();

    DDALine(x1,y1,x2,y1);       //drawing top line
    DDALine(x2,y1,x2,y2);       //drawing right line
    DDALine(x2,y2,x1,y2);       //drawing bottom line
    DDALine(x1,y2,x1,y1);       //drawing left line

    int x1c = (x1 + x2)/2;      //getting coordinates of midpoint
    int y1c = (y1 + y2)/2;

    // c0ordinates are (x1c, y1), (x2,y1c), (x1c, y2), (x1, y1c) respectively

    BresenhamLine(x1c, y1, x2, y1c); //drawing the inner parallelogram
    BresenhamLine(x2, y1c, x1c, y2);
    BresenhamLine(x1c, y2, x1, y1c);
    BresenhamLine(x1, y1c, x1c, y1);

    // coordinates for the points are ( (x1c+x1)/2 , (y1 + y1c)/2 ) , center coordinates are = x1+x2/2 , y1+y2/2

    float h1 = abs(x1-x2)/2;
    float w1 = abs(y1-y2)/2;

    float reqRadius = h1 * w1 / sqrt(h1*h1+w1*w1);      //calculating the radius of the inner circle

    BresenhamCircle(x1c, y1c, reqRadius);       //drawing the inner circle
}

//defining all the pushButton functions
void MainWindow::on_pushButton_clicked()
{
    QMessageBox message;
    if(ui->textEdit->toPlainText().isEmpty()||ui->textEdit_2->toPlainText().isEmpty()||ui->textEdit_3->toPlainText().isEmpty())
    {
        message.information(0,"Warning!","Fields except for x2 and y2 cannot be left empty!");      //EH for not having proper inputs
    }
    else if(ui->textEdit->toPlainText().toInt() && ui->textEdit_2->toPlainText().toInt() && ui->textEdit_3->toPlainText().toInt())
    {
       for (int x = 0; x < width; ++x)
       {
          for (int y = 0; y < height; ++y)
          {
             img.setPixel(x, y, qRgb(0, 0, 0));     //clearing the screen before printing the output
          }
       }
       ui->label->setPixmap(QPixmap::fromImage(img));
       Assignment6a();
    }

    else
    {
        message.information(0,"Warning!","Fields accept only numerical inputs!");      //EH for not having proper inputs
    }

}


void MainWindow::on_pushButton_2_clicked()
{
    QRgb color(QColorDialog::getColor().rgb()); //Able to select any color to draw
    rgb = color;
}

void MainWindow::on_pushButton_3_clicked()
{
    for (int x = 0; x < width; ++x)
        {
            for (int y = 0; y < height; ++y)
            {
                img.setPixel(x, y, qRgb(0, 0, 0));      //setting all the pixels on the screen to black (0,0,0)
            }
        }
        ui->label->setPixmap(QPixmap::fromImage(img));
}


void MainWindow::on_pushButton_4_clicked()
{
    QMessageBox message;
    if(ui->textEdit->toPlainText().isEmpty()||ui->textEdit_2->toPlainText().isEmpty()||ui->textEdit_4->toPlainText().isEmpty()||ui->textEdit_5->toPlainText().isEmpty())
    {
        message.information(0,"Warning!","Fields except for radius cannot be left empty!");     //EH for empty inputs
    }
    else if(ui->textEdit->toPlainText().toInt() && ui->textEdit_2->toPlainText().toInt() && ui->textEdit_4->toPlainText().toInt() && ui->textEdit_5->toPlainText().toInt())
    {
        for (int x = 0; x < width; ++x)
        {
           for (int y = 0; y < height; ++y)
           {
              img.setPixel(x, y, qRgb(0, 0, 0));        //clearing the screen before printing the output
           }
        }
       ui->label->setPixmap(QPixmap::fromImage(img));
       Assignment6b();
    }

    else
    {
        message.information(0,"Warning!","Fields accept only numerical inputs!");     //EH for empty inputs
    }

}

